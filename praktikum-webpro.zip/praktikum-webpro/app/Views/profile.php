<?= $this->extend('layout') ?>
<?= $this->section('content') ?>
<h2>My Profile</h2>
<p>Silvi Nurcahyaningsih</p>
<?= $this->endSection() ?>