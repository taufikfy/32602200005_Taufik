<!DOCTYPE html>
<html lang="en">
<head>
    <title>Document</title>
</head>
<body>
    <form action="/profile" method="POST">
    <label for="">Username : </label>
    <input name="nama" type="text"><br>
    <label for="">Password : </label>
    <input name="pass" type="password">
    <br>
    <button>submit</button>
</form>
</body>
</html>