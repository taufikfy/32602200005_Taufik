<?= $this->extend('layout') ?>
<?= $this->section('content') ?>
<h2>My Experience</h2>
<ul>
    <li>3 years of experience in font-end web development</li>
    <li>Proficient in HTML, CSS, JavaScript, and Query</li>
    <li>Familiar with frameworks like Codeigniter and Laravel</li>
</ul>
<?= $this->endSection() ?>