<?php $this->extend('layout/32602200007_silvi') ?>
<?php $this->section('content') ?>
<div class="about">
  <div class="about-me">
    <h1>About Me</h1>
    <p>An Undergraduate student at the Faculty of Industrial
       Technology majoring Informatics Engineering
        from the Islamic University of Sultan Agung</p>
  </div>

  <div class="about-experience">
    <h2>Experience</h2>
    <div class="about-experience-list">
      <table border="1" cellspacing="0">
        <tr>
          <th rowspan="3">2021</th>
          <th colspan="2">UI/UX Design Intership</th>
          <th rowspan="3">2022</th>
          <th colspan="2">Freelance UI/UX Design</th>
        </tr>
        <tr>
          <td>Yogyakarta</td>
          <td>Indonesia</td>
          <td>Yogyakarta</td>
          <td>Indonesia</td>
        </tr>
        <tr>
          <td colspan="2">Lorem ipsum dolor sit amet consectetur
             adipisicing elit. Maxime eveniet ut corporis adipisci
            iusto labore, quam, et neque quod, dignissimos temporibus voluptatum. 
            Nam totam eligendi assumenda cum architecto tenetur et.</td>
          <td colspan="2">Lorem ipsum dolor sit amet consectetur 
            adipisicing elit. Delectus doloremque repellat quas harum,
             amet dicta dolorum! Deleniti mollitia, 
             natus sed voluptates illum expedita, ut eius dicta 
             laudantium non qui eaque.</td>
        </tr>
        <tr>
          <th rowspan="3">2023</th>
          <th colspan="2">Web Design</th>
          <th rowspan="3">2024</th>
          <th colspan="2">Freelance Web Design</th>
        </tr>
        <tr>
          <td>Yogyakarta</td>
          <td>Indonesia</td>
          <td>Yogyakarta</td>
          <td>Indonesia</td>
        </tr>
        <tr>
          <td colspan="2">Lorem ipsum, dolor sit amet consectetur
             adipisicing elit. Enim ratione odit voluptatem id 
             quidem fuga itaque quaerat ea iure soluta! Dolore est
              eveniet veniam amet eius soluta numquam quos dolorem.</td>
          <td colspan="2">Lorem ipsum dolor sit amet consectetur
             adipisicing elit. Odit dolore rerum, aliquam commodi hic 
             animi pariatur sit unde culpa, debitis molestias accusantium, ducimus ipsa
              corrupti ipsam quidem id iste ullam.</td>
        </tr>
      </table>
    </div>
  </div>
</div>
<?= $this->endSection() ?>