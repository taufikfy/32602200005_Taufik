<?php

namespace App\Controllers;

class HelloWorld extends BaseController 
{
        public function halodunia()
        {
            return view('helloworld');
        }
}
?>